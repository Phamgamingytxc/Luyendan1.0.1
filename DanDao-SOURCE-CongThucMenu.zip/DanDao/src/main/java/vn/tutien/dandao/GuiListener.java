package vn.tutien.dandao;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;

public class GuiListener implements Listener {
    private final DanDao plugin;
    public GuiListener(DanDao plugin) { this.plugin = plugin; }

    private static boolean isInput(int slot) {
        for (int s : FurnaceGui.INPUT) if (s == slot) return true;
        return false;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof RecipeMenu) {
            e.setCancelled(true);
            if (e.getRawSlot() == 49 && e.getWhoClicked() instanceof Player p) {
                p.closeInventory();
                p.openInventory(new FurnaceGui(plugin, p).getInventory());
            }
            return;
        }
        if (!(e.getView().getTopInventory().getHolder() instanceof FurnaceGui g)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (g.brewing || e.isShiftClick() || e.getClick() == ClickType.DOUBLE_CLICK) { e.setCancelled(true); return; }
        if (e.getClickedInventory() == e.getView().getTopInventory()) {
            int slot = e.getRawSlot();
            if (isInput(slot)) return;
            e.setCancelled(true);
            if (slot == FurnaceGui.FIRE) g.cycleFire();
            else if (slot == FurnaceGui.START) g.start(p);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof RecipeMenu) {
            e.setCancelled(true);
            return;
        }
        if (!(e.getView().getTopInventory().getHolder() instanceof FurnaceGui g)) return;
        for (int s : e.getRawSlots()) {
            if (s < 27 && (!isInput(s) || g.brewing)) { e.setCancelled(true); return; }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof FurnaceGui g && e.getPlayer() instanceof Player p) g.returnItems(p);
    }
}
