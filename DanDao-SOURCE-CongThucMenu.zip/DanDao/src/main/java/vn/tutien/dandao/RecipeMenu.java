package vn.tutien.dandao;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public final class RecipeMenu implements InventoryHolder {
    private final Inventory inventory;

    public RecipeMenu(DanDao plugin, Player player) {
        inventory = plugin.getServer().createInventory(this, 54,
                DanDao.c("&6&lBách Khoa Đan Phương"));
        ItemStack filler = item(Material.BLACK_STAINED_GLASS_PANE, "&8 ", List.of());
        for (int i = 0; i < 54; i++) inventory.setItem(i, filler);

        int slot = 10;
        for (Recipe recipe : plugin.recipes.values()) {
            if (slot == 17) slot = 19;
            if (slot == 26) slot = 28;
            if (slot == 35) slot = 37;
            if (slot >= 44) break;

            List<String> lore = new ArrayList<>();
            lore.add("&8━━━━━━━━━━━━━━━━");
            lore.add("&7Cấp Đan Sư yêu cầu: &e" + recipe.level);
            lore.add("&7Thời gian luyện: &f" + recipe.time + " giây");
            lore.add("&7Tỉ lệ cơ bản: &a" + recipe.baseChance + "%");
            lore.add("&7Nguyên liệu cần có:");
            for (var ingredient : recipe.ingredients.entrySet()) {
                ConfigurationSection herb = plugin.getConfig().getConfigurationSection("herbs." + ingredient.getKey());
                String herbName = herb == null ? ingredient.getKey() : herb.getString("name", ingredient.getKey());
                lore.add("&f • " + herbName + " &7x" + ingredient.getValue());
            }
            lore.add("&7Hiệu quả:");
            for (String desc : recipe.desc) lore.add(desc);
            for (String potion : recipe.potions) {
                String[] parts = potion.split(":");
                if (parts.length >= 3) lore.add("&b • " + parts[0] + " " + parts[1] + "s");
            }
            if (recipe.heal > 0) lore.add("&c • Hồi máu: +" + recipe.heal);
            lore.add("&8Dùng /dan lo để luyện đan");
            inventory.setItem(slot++, item(Material.matchMaterial(recipe.material) == null
                    ? Material.PAPER : Material.matchMaterial(recipe.material),
                    recipe.name, lore));
        }

        inventory.setItem(49, item(Material.BLAZE_POWDER, "&6&lĐan Lô",
                List.of("&7Mở giao diện luyện đan", "&e/dan lo")));
        inventory.setItem(45, item(Material.BOOK, "&e&lHướng dẫn",
                List.of("&7Xem công thức, nguyên liệu và yêu cầu", "&7Luyện đan bằng cách bỏ đủ nguyên liệu", "&7vào Đan Lô rồi nhấn Bắt đầu.")));
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(DanDao.c(name));
        List<Component> lines = new ArrayList<>();
        for (String line : lore) lines.add(DanDao.c(line));
        meta.lore(lines);
        stack.setItemMeta(meta);
        return stack;
    }

    @Override
    public @NotNull Inventory getInventory() { return inventory; }
}
