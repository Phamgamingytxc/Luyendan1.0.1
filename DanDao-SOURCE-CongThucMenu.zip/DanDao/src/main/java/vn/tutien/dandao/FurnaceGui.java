package vn.tutien.dandao;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class FurnaceGui implements InventoryHolder {
    public static final int[] INPUT = {10, 11, 12, 13, 14};
    public static final int FIRE = 16, START = 22;

    private final DanDao plugin;
    private final Inventory inv;
    private final List<String> fireKeys = new ArrayList<>();
    private int fire = 1;
    public boolean brewing = false;

    public FurnaceGui(DanDao plugin, Player p) {
        this.plugin = plugin;
        ConfigurationSection f = plugin.getConfig().getConfigurationSection("fires");
        if (f != null) fireKeys.addAll(f.getKeys(false));
        if (fire >= fireKeys.size()) fire = 0;
        inv = plugin.getServer().createInventory(this, 27, DanDao.c("&6&lĐan Lô &8- &7Đan Sư Phẩm " + plugin.level(p.getUniqueId())));
        ItemStack glass = named(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);
        for (int s : INPUT) inv.setItem(s, null);
        inv.setItem(START, named(Material.ANVIL, "&a&lBắt đầu luyện đan", List.of("&7Bỏ dược liệu vào 5 ô giữa", "&7rồi bấm để luyện")));
        inv.setItem(4, named(Material.BOOK, "&eĐan phương", List.of("&7Xem công thức bằng &f/dan list")));
        refreshFire();
    }

    private ItemStack named(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(DanDao.c(name));
        List<net.kyori.adventure.text.Component> l = new ArrayList<>();
        for (String s : lore) l.add(DanDao.c(s));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    private ConfigurationSection fireCfg() {
        return plugin.getConfig().getConfigurationSection("fires." + fireKeys.get(fire));
    }

    private void refreshFire() {
        if (fireKeys.isEmpty()) return;
        ConfigurationSection f = fireCfg();
        Material m = Material.matchMaterial(f.getString("material", "CAMPFIRE"));
        inv.setItem(FIRE, named(m == null ? Material.CAMPFIRE : m, "&6Hỏa: " + f.getString("name"),
                List.of("&7Thành công: &a+" + f.getInt("bonus") + "%",
                        "&7Thời gian: &fx" + f.getDouble("time-mult"),
                        "&8Bấm để đổi loại lửa")));
    }

    public void cycleFire() {
        if (fireKeys.isEmpty()) return;
        fire = (fire + 1) % fireKeys.size();
        refreshFire();
    }

    public void returnItems(Player p) {
        for (int s : INPUT) {
            ItemStack it = inv.getItem(s);
            if (it != null) { plugin.give(p, it); inv.setItem(s, null); }
        }
    }

    public void start(Player p) {
        Map<String, Integer> have = new HashMap<>();
        for (int s : INPUT) {
            ItemStack it = inv.getItem(s);
            if (it == null) continue;
            String id = plugin.herbId(it);
            if (id == null) { plugin.msg(p, "&cChỉ được bỏ &edược liệu &cvào đan lô!"); return; }
            have.merge(id, it.getAmount(), Integer::sum);
        }
        if (have.isEmpty()) { plugin.msg(p, "&cĐan lô đang trống!"); return; }

        Recipe recipe = null;
        for (Recipe r : plugin.recipes.values()) if (r.ingredients.equals(have)) { recipe = r; break; }
        if (recipe == null) { plugin.msg(p, "&cDược liệu không khớp đan phương nào!"); p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6f, 1f); return; }

        int lvl = plugin.level(p.getUniqueId());
        if (lvl < recipe.level) { plugin.msg(p, "&cCần &eĐan Sư Phẩm " + recipe.level + " &cđể luyện " + recipe.name + "&c!"); return; }

        for (int s : INPUT) inv.setItem(s, null);
        brewing = true;
        ConfigurationSection f = fireCfg();
        final double bonus = f == null ? 0 : f.getDouble("bonus");
        final double tmult = f == null ? 1 : f.getDouble("time-mult", 1);
        final int totalTicks = (int) Math.max(20, recipe.time * tmult * 20);
        final Recipe fr = recipe;
        final Location where = p.getLocation().clone();
        final UUID uuid = p.getUniqueId();

        plugin.msg(p, "&7Bắt đầu luyện " + recipe.name + "&7...");
        new BukkitRunnable() {
            int t = 0;
            @Override public void run() {
                t += 10;
                Player pl = plugin.getServer().getPlayer(uuid);
                if (pl != null) {
                    int pct = Math.min(100, t * 100 / totalTicks);
                    pl.sendActionBar(DanDao.c("&6Đang luyện " + fr.name + " &8| &e" + pct + "%"));
                    pl.playSound(pl.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.5f, 1f);
                }
                if (t >= totalTicks) {
                    cancel();
                    brewing = false;
                    finish(uuid, fr, bonus, where);
                }
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    private void finish(UUID uuid, Recipe r, double fireBonus, Location where) {
        Player p = plugin.getServer().getPlayer(uuid);
        int lvl = plugin.level(uuid);
        double perLv = plugin.getConfig().getDouble("settings.success-per-level", 5);
        double chance = Math.max(5, Math.min(95, r.baseChance + (lvl - r.level) * perLv + fireBonus));
        Random rnd = new Random();
        boolean ok = rnd.nextDouble() * 100 < chance;

        if (ok) {
            double roll = rnd.nextDouble() * 100;
            double cuc = 2 + lvl, thuong = 15 + lvl * 2, trung = 35;
            int q = roll < cuc ? 3 : roll < cuc + thuong ? 2 : roll < cuc + thuong + trung ? 1 : 0;
            ItemStack pill = plugin.createPill(r, q);
            if (p != null) {
                plugin.give(p, pill);
                plugin.msg(p, "&aLuyện đan thành công! Nhận được " + r.name + " &8[" + DanDao.QUALITY_NAMES[q] + "&8]");
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
                plugin.addExp(p, r.exp);
            } else where.getWorld().dropItemNaturally(where, pill);
        } else {
            double ruinedChance = Math.max(0, Math.min(100,
                    plugin.getConfig().getDouble("alchemy.ruined-pill-chance-on-failure", 35)));
            boolean ruined = rnd.nextDouble() * 100 < ruinedChance;
            ItemStack failedResult = ruined ? plugin.createRuinedPill(r) : null;
            if (p != null) {
                if (failedResult != null) {
                    plugin.give(p, failedResult);
                    plugin.msg(p, "&cLuyện đan thất bại! &8Lò đan kết thành &7Hư Đan &8(" + (int) ruinedChance + "% cơ hội khi thất bại). ");
                } else {
                    plugin.msg(p, "&cLuyện đan thất bại, dược liệu hóa thành tro bụi...");
                }
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.4f);
                plugin.addExp(p, Math.max(1, r.exp / 4));
            } else if (failedResult != null) {
                where.getWorld().dropItemNaturally(where, failedResult);
            }
        }
    }

    @Override public @NotNull Inventory getInventory() { return inv; }
}
