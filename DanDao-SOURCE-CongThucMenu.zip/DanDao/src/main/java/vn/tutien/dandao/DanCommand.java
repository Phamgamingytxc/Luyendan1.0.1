package vn.tutien.dandao;

import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class DanCommand implements CommandExecutor, TabCompleter {
    private final DanDao plugin;
    public DanCommand(DanDao plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String sub = a.length == 0 ? "lo" : a[0].toLowerCase();
        switch (sub) {
            case "lo" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Chỉ dành cho người chơi."); return true; }
                p.openInventory(new FurnaceGui(plugin, p).getInventory());
            }
            case "congthuc", "menu", "recipe", "recipes" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Chỉ dành cho người chơi."); return true; }
                p.openInventory(new RecipeMenu(plugin, p).getInventory());
            }
            case "info" -> {
                if (!(s instanceof Player p)) return true;
                int lv = plugin.level(p.getUniqueId());
                plugin.msg(p, "&eĐan Sư Phẩm " + lv + " &7| Exp: &f" + plugin.exp(p.getUniqueId()) + "/" + plugin.expNeeded(lv)
                        + " &7| Đan độc: &c" + plugin.toxicity.getOrDefault(p.getUniqueId(), 0.0).intValue());
            }
            case "list" -> {
                s.sendMessage(DanDao.c("&6===== Đan Phương ====="));
                for (Recipe r : plugin.recipes.values()) {
                    StringBuilder sb = new StringBuilder();
                    for (var e : r.ingredients.entrySet()) {
                        String name = plugin.getConfig().getString("herbs." + e.getKey() + ".name", e.getKey());
                        sb.append(name).append("&7 x").append(e.getValue()).append("&8, ");
                    }
                    s.sendMessage(DanDao.c(r.name + " &8(Phẩm " + r.level + ", " + r.time + "s) &7: " + sb));
                }
            }
            case "give" -> {
                if (!s.hasPermission("dandao.admin")) { s.sendMessage("Không có quyền."); return true; }
                if (a.length < 4) { s.sendMessage("/dan give <herb|pill> <người> <tên vật phẩm có dấu cách> [số lượng|phẩm chất 0-3]"); return true; }
                Player t = Bukkit.getPlayer(a[2]);
                if (t == null) { s.sendMessage("Người chơi không online."); return true; }
                boolean herb = a[1].equalsIgnoreCase("herb");
                int last = a.length - 1;
                int n = 1;
                if (last >= 4 && isInteger(a[last])) n = parse(a[last--], 1);
                String displayName = String.join(" ", Arrays.copyOfRange(a, 3, last + 1));
                String itemKey = herb ? findHerbKey(displayName) : findRecipeKey(displayName);
                ItemStack it;
                if (herb) it = itemKey == null ? null : plugin.createHerb(itemKey, Math.max(1, n));
                else {
                    Recipe r = itemKey == null ? null : plugin.recipes.get(itemKey);
                    it = r == null ? null : plugin.createPill(r, Math.max(0, Math.min(3, n)));
                }
                if (it == null) { s.sendMessage("Không tìm thấy tên vật phẩm: " + displayName); return true; }
                plugin.give(t, it);
                s.sendMessage("Đã đưa vật phẩm cho " + t.getName());
            }
            case "setlevel" -> {
                if (!s.hasPermission("dandao.admin")) { s.sendMessage("Không có quyền."); return true; }
                if (a.length < 3) { s.sendMessage("/dan setlevel <người> <cấp>"); return true; }
                Player t = Bukkit.getPlayer(a[1]);
                if (t == null) { s.sendMessage("Người chơi không online."); return true; }
                plugin.setLevel(t.getUniqueId(), Math.max(1, Math.min(plugin.getConfig().getInt("settings.max-level", 9), parse(a[2], 1))));
                s.sendMessage("Đã đặt cấp đan sư.");
            }
            case "reload" -> {
                if (!s.hasPermission("dandao.admin")) { s.sendMessage("Không có quyền."); return true; }
                plugin.reload();
                s.sendMessage("Đã reload cấu hình.");
            }
            default -> s.sendMessage("/dan [lo|congthuc|info|list|give|setlevel|reload]");
        }
        return true;
    }

    private int parse(String s, int def) { try { return Integer.parseInt(s); } catch (Exception e) { return def; } }
    private boolean isInteger(String s) { try { Integer.parseInt(s); return true; } catch (Exception e) { return false; } }
    private String plain(String s) { return s.replaceAll("&[0-9a-fk-orA-FK-OR]", "").replaceAll("§[0-9a-fk-orA-FK-OR]", "").trim(); }
    private String findHerbKey(String input) {
        var section = plugin.getConfig().getConfigurationSection("herbs");
        if (section == null) return null;
        for (String key : section.getKeys(false)) {
            String name = plain(plugin.getConfig().getString("herbs." + key + ".name", key));
            if (key.equalsIgnoreCase(input) || name.equalsIgnoreCase(input)) return key;
        }
        return null;
    }
    private String findRecipeKey(String input) {
        for (Recipe recipe : plugin.recipes.values())
            if (recipe.id.equalsIgnoreCase(input) || plain(recipe.name).equalsIgnoreCase(input)) return recipe.id;
        return null;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) out.addAll(List.of("lo", "congthuc", "menu", "info", "list", "give", "setlevel", "reload"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("give")) out.addAll(List.of("herb", "pill"));
        else if (a.length == 3 && a[0].equalsIgnoreCase("give")) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        else if (a.length == 4 && a[0].equalsIgnoreCase("give")) {
            if (a[1].equalsIgnoreCase("herb")) {
                var h = plugin.getConfig().getConfigurationSection("herbs");
                if (h != null) for (String key : h.getKeys(false)) out.add(plain(plugin.getConfig().getString("herbs." + key + ".name", key)));
            } else for (Recipe recipe : plugin.recipes.values()) out.add(plain(recipe.name));
        }
        out.removeIf(x -> !x.toLowerCase().startsWith(a[a.length - 1].toLowerCase()));
        return out;
    }
}
