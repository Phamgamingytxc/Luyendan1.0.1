package vn.tutien.dandao;

import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

public final class Recipe {
    public final String id, name, material;
    public final int level, time, exp;
    public final double baseChance, toxicity, heal;
    public final Map<String, Integer> ingredients = new LinkedHashMap<>();
    public final List<String> desc, potions, commands;

    public Recipe(String id, ConfigurationSection s) {
        this.id = id;
        this.name = s.getString("name", id);
        this.material = s.getString("material", "PAPER");
        this.level = s.getInt("level", 1);
        this.time = s.getInt("time", 5);
        this.exp = s.getInt("exp", 10);
        this.baseChance = s.getDouble("base-chance", 50);
        this.toxicity = s.getDouble("toxicity", 5);
        this.heal = s.getDouble("heal", 0);
        ConfigurationSection ing = s.getConfigurationSection("ingredients");
        if (ing != null) for (String k : ing.getKeys(false)) ingredients.put(k, ing.getInt(k));
        this.desc = s.getStringList("desc");
        this.potions = s.getStringList("potions");
        this.commands = s.getStringList("commands");
    }
}
