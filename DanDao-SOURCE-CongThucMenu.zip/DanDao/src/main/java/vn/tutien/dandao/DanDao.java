package vn.tutien.dandao;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DanDao extends JavaPlugin {
    public static final String PREFIX = "&6[Đan Đạo] &r";
    public static final String[] QUALITY_NAMES = {"&7Hạ Phẩm", "&aTrung Phẩm", "&bThượng Phẩm", "&6&lCực Phẩm"};
    public static final double[] QUALITY_MULT = {0.8, 1.0, 1.3, 1.8};

    public NamespacedKey keyHerb, keyPill, keyQuality;
    public final Map<String, Recipe> recipes = new LinkedHashMap<>();
    public final Map<UUID, Double> toxicity = new HashMap<>();
    public final Map<UUID, Long> cooldown = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        keyHerb = new NamespacedKey(this, "herb");
        keyPill = new NamespacedKey(this, "pill");
        keyQuality = new NamespacedKey(this, "quality");
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        loadRecipes();

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new PillListener(this), this);
        getServer().getPluginManager().registerEvents(new HarvestListener(this), this);
        DanCommand cmd = new DanCommand(this);
        getCommand("dan").setExecutor(cmd);
        getCommand("dan").setTabCompleter(cmd);

        double decay = getConfig().getDouble("settings.toxicity-decay-per-minute", 5);
        getServer().getScheduler().runTaskTimer(this, () -> {
            Iterator<Map.Entry<UUID, Double>> it = toxicity.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Double> e = it.next();
                double v = e.getValue() - decay;
                if (v <= 0) it.remove(); else e.setValue(v);
            }
        }, 1200L, 1200L);
    }

    public void reload() {
        reloadConfig();
        loadRecipes();
    }

    private void loadRecipes() {
        recipes.clear();
        ConfigurationSection s = getConfig().getConfigurationSection("recipes");
        if (s == null) return;
        for (String k : s.getKeys(false)) recipes.put(k, new Recipe(k, s.getConfigurationSection(k)));
    }

    // ---------- tiện ích ----------
    public static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public void msg(Player p, String s) { p.sendMessage(c(PREFIX + s)); }

    // ---------- cấp đan sư ----------
    public int level(UUID id) { return data.getInt(id + ".level", 1); }
    public int exp(UUID id) { return data.getInt(id + ".exp", 0); }
    public int expNeeded(int level) { return getConfig().getInt("settings.exp-base", 100) * level; }

    public void setLevel(UUID id, int lv) {
        data.set(id + ".level", lv);
        data.set(id + ".exp", 0);
        saveData();
    }

    public void addExp(Player p, int amount) {
        UUID id = p.getUniqueId();
        int max = getConfig().getInt("settings.max-level", 9);
        int lv = level(id), xp = exp(id) + amount;
        while (lv < max && xp >= expNeeded(lv)) {
            xp -= expNeeded(lv);
            lv++;
            msg(p, "&aChúc mừng! Bạn đã thăng lên &eĐan Sư Phẩm " + lv + "&a!");
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        if (lv >= max) xp = 0;
        data.set(id + ".level", lv);
        data.set(id + ".exp", xp);
        saveData();
    }

    private void saveData() {
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("Không lưu được data.yml: " + e.getMessage()); }
    }

    // ---------- vật phẩm ----------
    public String herbId(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(keyHerb, PersistentDataType.STRING);
    }

    public ItemStack createHerb(String id, int amount) {
        ConfigurationSection h = getConfig().getConfigurationSection("herbs." + id);
        if (h == null) return null;
        Material m = Material.matchMaterial(h.getString("material", "FERN"));
        if (m == null) m = Material.FERN;
        ItemStack it = new ItemStack(m, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(h.getString("name", id)));
        List<Component> lore = new ArrayList<>();
        for (String l : h.getStringList("lore")) lore.add(c(l));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(keyHerb, PersistentDataType.STRING, id);
        it.setItemMeta(meta);
        return it;
    }

    public ItemStack createPill(Recipe r, int quality) {
        Material m = Material.matchMaterial(r.material);
        if (m == null) m = Material.PAPER;
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(r.name + " &8[" + QUALITY_NAMES[quality] + "&8]"));
        List<Component> lore = new ArrayList<>();
        for (String l : r.desc) lore.add(c(l));
        lore.add(c("&7Phẩm chất: " + QUALITY_NAMES[quality] + " &7(x" + QUALITY_MULT[quality] + ")"));
        lore.add(c("&7Đan độc: &c+" + (int) r.toxicity));
        lore.add(c("&8Chuột phải để dùng"));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(keyPill, PersistentDataType.STRING, r.id);
        meta.getPersistentDataContainer().set(keyQuality, PersistentDataType.INTEGER, quality);
        it.setItemMeta(meta);
        return it;
    }

    public ItemStack createRuinedPill(Recipe r) {
        ItemStack it = new ItemStack(Material.GRAY_DYE);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c("&8&lHư Đan: " + r.name));
        List<Component> lore = new ArrayList<>();
        lore.add(c("&7Linh lực hỗn loạn, đan văn vỡ nát."));
        lore.add(c("&cĐan dược luyện hỏng, không thể sử dụng."));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    public void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        for (ItemStack l : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), l);
    }
}
