package vn.tutien.dandao;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PillListener implements Listener {
    private final DanDao plugin;
    public PillListener(DanDao plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();

        // Dùng đan
        if ((a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK) && hand.hasItemMeta()) {
            var pdc = hand.getItemMeta().getPersistentDataContainer();
            String pillId = pdc.get(plugin.keyPill, PersistentDataType.STRING);
            if (pillId != null) {
                e.setCancelled(true);
                Recipe r = plugin.recipes.get(pillId);
                if (r == null) { plugin.msg(p, "&cĐan phương này không còn tồn tại."); return; }
                int q = Math.max(0, Math.min(3, pdc.getOrDefault(plugin.keyQuality, PersistentDataType.INTEGER, 1)));
                usePill(p, hand, r, q);
                return;
            }
        }

        // Mở đan lô
        if (a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null && !p.isSneaking()) {
            Material furnace = Material.matchMaterial(plugin.getConfig().getString("settings.furnace-block", "BLAST_FURNACE"));
            if (furnace != null && e.getClickedBlock().getType() == furnace) {
                e.setCancelled(true);
                p.openInventory(new FurnaceGui(plugin, p).getInventory());
            }
        }
    }

    private void usePill(Player p, ItemStack item, Recipe r, int q) {
        long now = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("settings.pill-cooldown", 3) * 1000L;
        Long last = plugin.cooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { plugin.msg(p, "&cĐan lực chưa tan, hãy đợi một chút!"); return; }
        plugin.cooldown.put(p.getUniqueId(), now);

        double mult = DanDao.QUALITY_MULT[q];
        item.setAmount(item.getAmount() - 1);

        for (String s : r.potions) {
            String[] part = s.split(":");
            if (part.length < 3) continue;
            PotionEffectType type = Registry.POTION_EFFECT_TYPE.get(NamespacedKey.minecraft(part[0].toLowerCase()));
            if (type == null) { plugin.getLogger().warning("Hiệu ứng không tồn tại: " + part[0]); continue; }
            try {
                int ticks = (int) (Double.parseDouble(part[1]) * mult * 20);
                p.addPotionEffect(new PotionEffect(type, ticks, Integer.parseInt(part[2])));
            } catch (NumberFormatException ignored) { }
        }
        if (r.heal > 0) {
            AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
            double maxHp = max == null ? 20 : max.getValue();
            p.setHealth(Math.min(maxHp, p.getHealth() + r.heal * mult));
        }
        for (String cmd : r.commands) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    cmd.replace("%player%", p.getName()).replace("%mult%", String.valueOf(mult)).replace("%quality%", String.valueOf(q)));
        }
        p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_DRINK, 1f, 1f);
        plugin.msg(p, "&aBạn đã dùng " + r.name + "&a.");

        // Đan độc
        double max = plugin.getConfig().getDouble("settings.toxicity-max", 100);
        double tox = plugin.toxicity.merge(p.getUniqueId(), r.toxicity, Double::sum);
        if (tox > max) {
            plugin.msg(p, "&4Đan độc tích tụ quá nhiều! &cCơ thể không chịu nổi...");
            p.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 200, 0));
            p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 100, 1));
            plugin.toxicity.put(p.getUniqueId(), max * 0.7);
        } else {
            plugin.msg(p, "&7Đan độc: &c" + (int) tox + "&7/" + (int) max);
        }
    }
}
