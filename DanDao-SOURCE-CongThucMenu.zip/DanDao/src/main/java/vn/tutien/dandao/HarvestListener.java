package vn.tutien.dandao;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class HarvestListener implements Listener {
    private final DanDao plugin;
    public HarvestListener(DanDao plugin) { this.plugin = plugin; }

    @EventHandler(ignoreCancelled = true)
    public void onGrassBreak(BlockBreakEvent event) {
        if (!plugin.getConfig().getBoolean("harvest.enabled", true)) return;
        Block block = event.getBlock();
        if (!isHarvestBlock(block.getType())) return;
        Player player = event.getPlayer();
        if (player.getGameMode().name().equals("CREATIVE")) return;

        // A separate, very small roll for an intact pill.
        double pillChance = plugin.getConfig().getDouble("harvest.pill-chance-percent", 0.25);
        if (!plugin.recipes.isEmpty() && roll(pillChance)) {
            List<Recipe> candidates = new ArrayList<>();
            int playerLevel = plugin.level(player.getUniqueId());
            for (Recipe r : plugin.recipes.values()) if (r.level <= playerLevel) candidates.add(r);
            if (candidates.isEmpty()) return;
            Recipe recipe = candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
            int q = ThreadLocalRandom.current().nextDouble() < 0.03 ? 3
                    : ThreadLocalRandom.current().nextDouble() < 0.15 ? 2
                    : ThreadLocalRandom.current().nextDouble() < 0.45 ? 1 : 0;
            ItemStack pill = plugin.createPill(recipe, q);
            if (pill != null) {
                plugin.give(player, pill);
                plugin.msg(player, "&dBạn tìm thấy &f" + recipe.name + "&d trong bụi cỏ!");
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.5f);
                return;
            }
        }

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("harvest.herb-drops");
        if (section == null) return;
        double roll = ThreadLocalRandom.current().nextDouble(100.0);
        double cumulative = 0.0;
        for (String herbId : section.getKeys(false)) {
            double chance = Math.max(0, section.getDouble(herbId, 0));
            cumulative += chance;
            if (roll < cumulative) {
                ItemStack herb = plugin.createHerb(herbId, 1);
                if (herb != null) {
                    plugin.give(player, herb);
                    String name = plugin.getConfig().getString("herbs." + herbId + ".name", herbId);
                    plugin.msg(player, "&aBạn nhặt được linh thảo: " + name + "&a!");
                    player.playSound(player.getLocation(), Sound.BLOCK_GRASS_BREAK, 0.7f, 1.3f);
                }
                return;
            }
        }
    }

    private boolean isHarvestBlock(Material m) {
        return switch (m) {
            case SHORT_GRASS, TALL_GRASS, FERN, LARGE_FERN, DEAD_BUSH,
                 DANDELION, POPPY, BLUE_ORCHID, ALLIUM, AZURE_BLUET,
                 RED_TULIP, ORANGE_TULIP, WHITE_TULIP, PINK_TULIP,
                 OXEYE_DAISY, CORNFLOWER, LILY_OF_THE_VALLEY,
                 TORCHFLOWER, PITCHER_PLANT -> true;
            default -> false;
        };
    }

    private boolean roll(double percent) {
        return ThreadLocalRandom.current().nextDouble(100.0) < Math.max(0, Math.min(100, percent));
    }
}
