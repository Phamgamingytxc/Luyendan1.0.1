DanDao - Paper 1.21.11 - Java 21

Tính năng thu thập mới:
- Đập cỏ/hoa (cỏ ngắn, cỏ cao, dương xỉ, bụi cây khô và các loại hoa) có tỷ lệ rơi linh thảo.
- Linh thảo phổ thông có tỷ lệ cao hơn; linh thảo quý như Vạn Niên Nhân Sâm, Băng Tâm Tủy, Phượng Vĩ Thảo có tỷ lệ rất thấp.
- Mỗi lần đập cỏ có 0.25% cơ hội nhận đan dược ngẫu nhiên; chỉ rơi đan có cấp yêu cầu không vượt cấp Đan Sư của người chơi.
- Tỷ lệ chỉnh trong config.yml mục harvest. herb-drops là phần trăm cộng dồn theo thứ tự khai báo.
- Tắt tính năng bằng harvest.enabled: false.

Lệnh chính:
/dan hoặc /dan lo - mở lò luyện đan
/dan info - xem cấp Đan Sư và đan độc
/dan list - xem đan phương
/dan give herb <người chơi> <tên linh thảo> <số lượng>
/dan give pill <người chơi> <tên đan dược> <phẩm chất 0-3>
/dan setlevel <người chơi> <cấp>
/dan reload - tải lại cấu hình

Build:
- Cần Java 21 và Maven.
- Mở terminal trong thư mục DanDao (nơi có pom.xml), chạy: mvn clean package
- JAR nằm trong target/.

Nội dung mở rộng:
- Thêm 50 loại linh thảo mới (tổng 61 linh thảo trong config.yml).
- Thêm 50 đan phương mới, mỗi đan phương dùng linh thảo mở rộng; tổng 62 đan phương.
- Linh thảo mới có tỷ lệ thu thập thấp dần; có thể chỉnh từng tỷ lệ tại harvest.herb-drops.
- Khi luyện đan thất bại, mặc định có 35% cơ hội tạo ra vật phẩm Hư Đan không thể sử dụng; chỉnh tại alchemy.ruined-pill-chance-on-failure.
- Xác suất thành công riêng của từng đan phương nằm ở recipes.<id>.base-chance.


BỔ SUNG ĐỢT 2:
- Thêm 50 linh thảo mới (tổng 111 loại linh thảo trong config).
- Thêm 50 công thức đan dược mới (tổng 112 đan phương).
- Tỷ lệ thu thập linh thảo đợt 2 giảm dần theo độ hiếm.
- Khi luyện đan thất bại, config alchemy.ruined-pill-chance-on-failure quyết định tỷ lệ tạo Hư Đan (mặc định 35%).


MENU CONG THUC DAN DUOC
- /dan congthuc (hoac /dan menu): mo menu Bách Khoa Đan Phương.
- Menu hiển thị tên đan dược, nguyên liệu và số lượng, cấp Đan Sư, thời gian, tỉ lệ cơ bản, mô tả/hiệu quả.
- Bấm biểu tượng Đan Lô ở ô dưới để mở giao diện luyện đan.
- /dan lo: mở trực tiếp Đan Lô.
